# VTUKPL Premier League Alpha

This is the alpha version of the VTUKPL Premier League website built with React, Vite, Tailwind CSS, and Socket.IO.

## Setup

1. Clone the repo
2. Install dependencies
3. Run `npm run dev` and visit http://localhost:5173

