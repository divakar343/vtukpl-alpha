import React from 'react';
import { Link } from 'react-router-dom';
export default function Navbar() {
  return (
    <nav className="bg-blue-600 text-white p-4">
      <ul className="flex space-x-6 container mx-auto">
        <li><Link to="/" className="font-bold">VTUKPL</Link></li>
        <li><Link to="/teams">Teams</Link></li>
        <li><Link to="/schedule">Schedule</Link></li>
        <li><Link to="/live">Live Scores</Link></li>
        <li><Link to="/auction">Auction</Link></li>
      </ul>
    </nav>
  );
}
