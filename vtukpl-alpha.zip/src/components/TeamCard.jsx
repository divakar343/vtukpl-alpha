import React from 'react';
export default function TeamCard({ team }) {
  return (
    <div className="border rounded p-4 shadow hover:shadow-lg">
      <h3 className="text-xl font-semibold">{team.name}</h3>
      <p>Captain: {team.captainName}</p>
    </div>
  );
}
