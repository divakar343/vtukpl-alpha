import React, { useState } from 'react';
export default function BidWidget({ playerId, onBid }) {
  const [amount, setAmount] = useState('');
  return (
    <div className="mt-2">
      <input
        type="number"
        value={amount}
        onChange={e => setAmount(e.target.value)}
        placeholder="Your bid"
        className="border rounded p-1 w-24"
      />
      <button
        onClick={() => onBid(playerId, Number(amount))}
        className="ml-2 bg-green-500 text-white px-3 py-1 rounded"
      >Place Bid</button>
    </div>
  );
}
