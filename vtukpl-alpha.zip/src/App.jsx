import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Teams from './pages/Teams';
import Auction from './pages/Auction';
import Schedule from './pages/Schedule';
import LiveScores from './pages/LiveScores';

export default function App() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow container mx-auto p-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/teams" element={<Teams />} />
          <Route path="/auction" element={<Auction />} />
          <Route path="/schedule" element={<Schedule />} />
          <Route path="/live" element={<LiveScores />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
