import io from 'socket.io-client';
export default io(process.env.VITE_SOCKET_URL || '/');
