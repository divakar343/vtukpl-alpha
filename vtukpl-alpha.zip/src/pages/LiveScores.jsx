import React, { useEffect, useState } from 'react';
export default function LiveScores() {
  const [scores, setScores] = useState([]);
  useEffect(() => {
    const interval = setInterval(() => {
      fetch('/api/scores').then(res => res.json()).then(setScores);
    }, 5000);
    return () => clearInterval(interval);
  }, []);
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Live Scores</h2>
      {scores.map(s => (
        <div key={s.matchId} className="border p-2 rounded mb-2">
          {s.teamA}: {s.scoreA} | {s.teamB}: {s.scoreB}
        </div>
      ))}
    </div>
  );
}
