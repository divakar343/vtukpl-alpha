import React, { useEffect, useState } from 'react';
import socket from '../socket';
import BidWidget from '../components/BidWidget';

export default function Auction() {
  const [players, setPlayers] = useState([]);

  useEffect(() => {
    fetch('/api/players').then(res => res.json()).then(setPlayers);
    socket.on('bidUpdate', data => {
      setPlayers(prev => prev.map(p => p.id === data.playerId ? { ...p, currentBid: data.amount } : p));
    });
  }, []);

  const handleBid = (playerId, amount) => {
    socket.emit('placeBid', { playerId, amount });
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Player Auction</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {players.map(p => (
          <div key={p.id} className="border p-4 rounded">
            <h3 className="text-xl">{p.name}</h3>
            <p>Current Bid: {p.currentBid || 0}</p>
            <BidWidget playerId={p.id} onBid={handleBid} />
          </div>
        ))}
      </div>
    </div>
  );
}
