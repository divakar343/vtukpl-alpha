import React, { useEffect, useState } from 'react';
import TeamCard from '../components/TeamCard';
export default function Teams() {
  const [teams, setTeams] = useState([]);
  useEffect(() => {
    fetch('/api/teams').then(res => res.json()).then(setTeams);
  }, []);
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {teams.map(t => <TeamCard key={t.id} team={t} />)}
    </div>
  );
}
