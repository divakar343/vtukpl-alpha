import React, { useEffect, useState } from 'react';
export default function Schedule() {
  const [matches, setMatches] = useState([]);
  useEffect(() => {
    fetch('/api/matches').then(res => res.json()).then(setMatches);
  }, []);
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Match Schedule</h2>
      <ul className="space-y-2">
        {matches.map(m => (
          <li key={m.id} className="border p-2 rounded">
            {m.teamA} vs {m.teamB} | {new Date(m.start_time).toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
}
