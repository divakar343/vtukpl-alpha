import React from 'react';
export default function Home() {
  return (
    <div className="text-center">
      <h1 className="text-4xl font-bold mb-4">Welcome to VTUKPL Premier League</h1>
      <p>Experience college cricket like never before!</p>
    </div>
  );
}
